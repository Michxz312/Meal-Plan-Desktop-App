package persistence;

import model.WeeklyMealPlan;
import org.json.JSONObject;

import java.io.*;

// Represents a writer that writes JSON representation of weekly meal plan to file
// This class is written from a reference from JsonSerializationDemo
public class JsonMealPlanWriter {
    private PrintWriter writer;
    private String fileName;

    // MODIFIES: this
    // EFFECTS: constructs JsonWriter to write into the fileName
    public JsonMealPlanWriter(String fileName) {
        this.fileName = fileName;
    }

    // MODIFIES: this
    // EFFECTS: opens writer; throws FileNotFoundException if destination file
    // cannot be opened for writing
    public void open() throws FileNotFoundException {
        writer = new PrintWriter(fileName);
    }

    // MODIFIES: this
    // EFFECTS: writes JSON representation of WeeklyMealPlan to file
    public void write(WeeklyMealPlan weeklyMealPlan) {
        JSONObject json = weeklyMealPlan.toJson();
        saveToFile(json.toString());
    }

    // MODIFIES: this
    // EFFECTS: closes writer
    public void close() {
        writer.close();
    }

    // MODIFIES: this
    // EFFECTS: writes string to file
    private void saveToFile(String json) {
        writer.print(json);
    }

}
