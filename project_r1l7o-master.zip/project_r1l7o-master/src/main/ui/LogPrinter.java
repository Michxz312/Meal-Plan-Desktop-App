package ui;

import model.EventLog;

public interface LogPrinter {
    void printLog(EventLog event);
}
