package ui;

// This is the main class that will tell Planner to run

public class Main {

    // EFFECTS: run application
    public static void main(String[] args) {
        new Planner();
    }
}
